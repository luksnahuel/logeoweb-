package com.logeoweb.controller;

import java.util.HashMap;
import java.util.Map;

public class Greeting {

	// https://stackoverflow.com/questions/27003715/hashmap-login-system-with-user-data
    private String id;
    private String content;
    // crear clase almacenando id y content
    public Map<String, String> userAndPassword = new HashMap<>();
    
    public void setId(String id) {
    	// Nombre de user
        this.id = id;
    }
    
    public String getId() {
        return id;
    }
 
    public void setContent(String content) {
        this.content = content;
    }

    public String getContent() {
        return content;
    }
    
    public void setuserAndPassword(Map<String,String> userAndPassword) {
    	// Nombre de user
        this.userAndPassword = userAndPassword;
        // agregando nombre de user y contrasenia
        userAndPassword.put(id, content);
    }
    
    public Map<String, String> getuserAndPassword() {
        return userAndPassword;
    }

}